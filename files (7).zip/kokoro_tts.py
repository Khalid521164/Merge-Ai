"""Kokoro natural voice for Merge AI.

Kokoro itself runs in a separate service (see the merge-ai-voice Space),
because Kokoro needs Python 3.10-3.12 and PyTorch, which Streamlit Community
Cloud cannot install reliably. This module only sends text to that service
and receives WAV audio, so it needs nothing beyond `requests`.

Settings (Streamlit Secrets or environment variables):
    KOKORO_API_URL    e.g. https://YOUR-NAME-merge-ai-voice.hf.space
    KOKORO_API_KEY    the same value as TTS_API_KEY on the service
    KOKORO_TIMEOUT    optional, seconds to wait for audio (default 90)
    KOKORO_MAX_CHARS  optional, longest text to speak (default 1500)

If anything fails, synthesize() raises and app.py falls back to browser speech.
"""
from __future__ import annotations

import logging
import os
import re
import threading
import time

import requests

_LOG = logging.getLogger(__name__)

VOICES = {
    "am_liam",
    "am_michael",
    "am_eric",
    "am_adam",
    "am_puck",
    "am_echo",
    "am_fenrir",
    "am_onyx",
}

_SESSION = requests.Session()
_WARM_LOCK = threading.Lock()
_LAST_WARM = 0.0


class KokoroUnavailable(RuntimeError):
    """Raised when the Kokoro service cannot return audio."""


def _setting(name, default=""):
    value = None
    try:
        import streamlit as st

        value = st.secrets.get(name)
    except Exception:
        value = None
    if value in (None, ""):
        value = os.environ.get(name, default)
    return str(value).strip()


def _url():
    return _setting("KOKORO_API_URL").rstrip("/")


def is_available():
    """True when the service is configured. Network errors are handled per answer."""
    return bool(_url() and _setting("KOKORO_API_KEY"))


def warm_up():
    """Wake the service in the background (a sleeping Space needs time to start)."""
    global _LAST_WARM
    url = _url()
    if not url:
        return
    with _WARM_LOCK:
        if time.time() - _LAST_WARM < 300:
            return
        _LAST_WARM = time.time()

    def ping():
        try:
            _SESSION.get(url + "/health", timeout=60)
        except requests.RequestException:
            pass

    threading.Thread(target=ping, daemon=True).start()


def clean_for_speech(text, max_chars=None):
    """Turn a Markdown answer into plain sentences that sound natural."""
    if max_chars is None:
        max_chars = int(_setting("KOKORO_MAX_CHARS", "1500") or 1500)

    text = str(text)
    text = re.sub(r"```[\s\S]*?```", " Code omitted. ", text)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", text)            # images
    text = re.sub(r"\[([^\]]+)\]\((?:https?://)[^)]*\)", r"\1", text)  # [label](link)
    text = re.sub(r"https?://\S+", "a source link", text)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.MULTILINE)  # bullets
    text = re.sub(r"^\s*\d+[.)]\s+", "", text, flags=re.MULTILINE)  # numbered lists
    text = re.sub(r"\n{2,}", ". ", text)                          # paragraph = pause
    text = re.sub(r"([^.!?:;,])\n", r"\1, ", text)                  # line break = short pause
    text = re.sub(r"[`*_#>\[\]|~]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"([.!?])\s*,", r"\1", text)
    text = re.sub(r"(\.\s*){2,}", ". ", text)

    if len(text) > max_chars:
        cut = text[:max_chars]
        end = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
        text = cut[: end + 1] if end > max_chars // 2 else cut
    return text.strip()


def synthesize(text, *, voice="am_liam", speed=1.03):
    """Return WAV bytes spoken by Kokoro. Raises KokoroUnavailable on failure."""
    url = _url()
    key = _setting("KOKORO_API_KEY")
    if not url or not key:
        raise KokoroUnavailable("Kokoro service is not configured")

    spoken = clean_for_speech(text)
    if not spoken:
        raise ValueError("No text to speak")
    if voice not in VOICES:
        voice = "am_liam"
    speed = max(0.8, min(float(speed), 1.3))
    timeout = float(_setting("KOKORO_TIMEOUT", "90") or 90)

    last_error = "unknown error"
    for attempt in range(2):  # one retry, for a service that is just waking up
        try:
            response = _SESSION.post(
                url + "/tts",
                json={"text": spoken, "voice": voice, "speed": speed},
                headers={"Authorization": "Bearer " + key},
                timeout=(10, timeout),
            )
        except requests.RequestException as exc:
            last_error = type(exc).__name__
        else:
            audio = response.content
            if response.status_code == 200 and audio[:4] == b"RIFF":
                return audio
            last_error = "HTTP %s" % response.status_code
            if response.status_code in (400, 401, 403):
                break  # retrying will not help
        if attempt == 0:
            time.sleep(3)

    _LOG.warning("Kokoro service failed: %s", last_error)
    raise KokoroUnavailable("Kokoro service failed: " + last_error)
