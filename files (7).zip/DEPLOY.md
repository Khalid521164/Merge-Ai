# Merge AI - Kokoro natural male voice (am_liam, speed 1.03)

## Why Kokoro was unavailable

1. `kokoro_tts.py` imports `numpy` on its first line, but `requirements.txt` no longer
   lists numpy, torch or kokoro. The import fails, `app.py` sets `synthesize = None`,
   and Live Voice falls back to the browser voice.
2. Adding them back cannot work on Streamlit Community Cloud with Python 3.14:
   - `kokoro 0.9.4` (and `misaki 0.9.4`) declare `Requires-Python >=3.10,<3.13`, so pip refuses them on 3.14.
   - `numpy 1.26.4` has no Python 3.14 wheel (only numpy 2.3+), so pip tried to compile it from source and failed.
   - Even on Python 3.12, pip would pull the CUDA build of PyTorch (several GB) into a small
     Community Cloud container, and load an 82M-parameter model inside the web app process.
     That is unreliable for a public app.

Decision: run Kokoro as a separate private API on Python 3.11 (Hugging Face Space, Docker),
and keep the Streamlit app light. Browser speech stays as the fallback.

## What changed

| File | Change |
|---|---|
| `streamlit-app/kokoro_tts.py` | Rewritten. Calls the Kokoro API with `requests`; no numpy/torch. Same `synthesize(text, voice=, speed=)` signature. Better Markdown-to-speech cleanup; cuts long answers at a sentence end. |
| `streamlit-app/app.py` | 4 small edits only: imports `is_available`/`warm_up`; Kokoro shown as available when the API is configured; wakes the service when the page loads; Kokoro is used only for English voice answers. Login, Supabase history, providers and Tavily are untouched. |
| `streamlit-app/voice_chat.py` | 3 small JS edits: the Kokoro option re-enables when the service is configured; a manual voice choice is respected; a clear message for non-English languages. UI unchanged. |
| `requirements.txt`, `packages.txt` | No change needed (`requests` is already listed). |
| `merge-ai-voice/` | New Kokoro TTS service: FastAPI, CPU PyTorch, model and am_liam voice baked into the image, Bearer-key protected. |

## Deployment (test first, then production)

1. Create the voice Space: huggingface.co -> New Space -> name `merge-ai-voice`, SDK **Docker**, hardware **CPU basic (free)**.
2. Upload the 6 files from `merge-ai-voice/` (including `.dockerignore`).
3. Space -> Settings -> Variables and secrets -> New **secret** `TTS_API_KEY` = a long random string
   (e.g. `python -c "import secrets; print(secrets.token_urlsafe(32))"`). Never commit it.
4. Wait for the build (first build ~10-15 min). Open `https://<user>-merge-ai-voice.hf.space/health`;
   expect `"status":"ok","ready":true`.
5. In GitHub, create a branch `kokoro-test` and put the 3 files from `streamlit-app/` on it.
6. Streamlit Cloud -> Create app -> same repo, branch `kokoro-test`, main file `app.py`.
   Copy all existing secrets, then add the lines from `secrets.toml.example`.
   Add the test app's URL to the Google OAuth redirect URIs (and the redirect URI secret) if login requires it.
7. Test (checklist below). When it passes, merge `kokoro-test` into `main` and add the same
   `KOKORO_*` secrets to the production app.

## Test status

Verified here:
- Kokoro 0.9.4 / misaki 0.9.4 metadata: Python <3.13 only. Confirmed pip rejects both on 3.14, and numpy 1.26.4 has no 3.14 wheel.
- Service requirements resolve together on Python 3.12 (numpy 2.2.x, transformers 4.49, spaCy 3.8, torch 2.5.1).
- Server endpoints tested with a stand-in model: health, 401 on missing/wrong key, WAV 24 kHz mono 16-bit, voice/speed clamping, long-text cut.
- Streamlit client tested against the server: unconfigured -> fallback, wrong key -> fallback with no retry, Markdown cleanup.
- All Python files compile.

Needs live testing (could not run here - no access to the model download host):
- Docker build on Hugging Face and real Kokoro audio quality for `am_liam` at 1.03.
- Generation speed on the free CPU (affects how long Live Voice waits). If too slow, lower `KOKORO_MAX_CHARS`.
- Wake-up time after the free Space sleeps; first answer may fall back to browser voice while it wakes.
- Autoplay on iPhone/Safari (the existing "Play answer" button still covers blocked autoplay).
- Google login redirect on the test app URL; Supabase history saving on the test app.

## Test checklist

- [ ] `/health` shows `ready: true`
- [ ] Sign in with Google works on the test app
- [ ] Old chats load from Supabase; a new chat saves and is there after refresh
- [ ] Gemini, Groq, OpenRouter answers work; web search (Tavily) returns sources
- [ ] 🔊 Listen under an answer plays a male Kokoro voice
- [ ] Live conversation, English: answer is spoken by Kokoro, then the mic listens again
- [ ] Live conversation, Bengali: browser voice speaks, status says "Kokoro speaks English only"
- [ ] Stop the Space (or change the key): answers still arrive and browser voice speaks
